package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.models.AiRequests;

public interface AiRequestsRepository extends JpaRepository<AiRequests, Long> {

}